"""
test_runner.py

Standalone script (uses `requests`) that exercises a locally running
GridWise service:

    1. GET  http://localhost:8000/health
    2. POST http://localhost:8000/optimize-energy  with SAMPLE-01 payload

Run the service first, e.g.:
    uvicorn main:app --host 0.0.0.0 --port 8000

Then run this script:
    python test_runner.py
"""

import json
import sys
import requests

BASE_URL = "http://localhost:8000"

SAMPLE_01 = {
    "scenario_id": "SAMPLE-01",
    "demand_kwh": [
        2.0, 1.8, 1.6, 1.5, 1.5, 1.8,
        2.5, 3.2, 3.0, 2.6, 2.4, 2.5,
        2.8, 2.6, 2.4, 2.5, 3.0, 4.2,
        5.5, 5.8, 4.8, 3.6, 2.8, 2.2,
    ],
    "solar_forecast_kwh": [
        0.0, 0.0, 0.0, 0.0, 0.0, 0.2,
        0.8, 1.8, 3.0, 4.2, 5.0, 5.6,
        5.8, 5.6, 5.0, 4.2, 3.0, 1.6,
        0.4, 0.0, 0.0, 0.0, 0.0, 0.0,
    ],
    "tariff_bdt_per_kwh": [
        6.5, 6.5, 6.5, 6.5, 6.5, 6.5,
        7.5, 7.5, 8.5, 8.5, 8.5, 8.5,
        8.5, 8.5, 8.5, 8.5, 8.5, 9.5,
        11.0, 11.0, 11.0, 9.5, 7.5, 6.5,
    ],
    "battery": {
        "capacity_kwh": 10.0,
        "initial_energy_kwh": 5.0,
        "min_reserve_kwh": 1.0,
        "max_charge_kwh_per_hour": 3.0,
        "max_discharge_kwh_per_hour": 3.0,
    },
    "operator_notes": [
        "Reduce solar output by 50% between 1 PM and 3 PM due to expected cloud cover.",
        "Maintain at least 20% battery reserve from 6 PM to 9 PM for evening backup safety.",
        "No battery charging allowed from 10 PM to midnight for scheduled maintenance.",
        "Cap grid usage at 2 kWh between 7 AM and 9 AM.",
        "Team stand-up meeting scheduled at 3 PM.",
    ],
}


def print_header(title: str) -> None:
    bar = "=" * 70
    print(f"\n{bar}\n{title}\n{bar}")


def test_health() -> bool:
    print_header("TEST 1: GET /health")
    try:
        resp = requests.get(f"{BASE_URL}/health", timeout=10)
    except requests.exceptions.ConnectionError:
        print("FAILED: could not connect to the service. Is it running on port 8000?")
        return False

    print(f"Status code: {resp.status_code}")
    try:
        print(json.dumps(resp.json(), indent=2))
    except ValueError:
        print(resp.text)

    ok = resp.status_code == 200 and resp.json().get("status") == "ok"
    print("RESULT:", "PASSED" if ok else "FAILED")
    return ok


def test_optimize_energy() -> bool:
    print_header("TEST 2: POST /optimize-energy (SAMPLE-01)")
    print("Request payload:")
    print(json.dumps(SAMPLE_01, indent=2))

    try:
        resp = requests.post(
            f"{BASE_URL}/optimize-energy", json=SAMPLE_01, timeout=120
        )
    except requests.exceptions.ConnectionError:
        print("FAILED: could not connect to the service. Is it running on port 8000?")
        return False

    print(f"\nStatus code: {resp.status_code}")

    try:
        body = resp.json()
    except ValueError:
        print("FAILED: response was not valid JSON")
        print(resp.text)
        return False

    print("\nResponse body:")
    print(json.dumps(body, indent=2))

    if resp.status_code != 200:
        print("RESULT: FAILED (non-200 status code)")
        return False

    required_keys = {
        "scenario_id",
        "directive_interpretation",
        "hourly_plan",
        "total_grid_kwh",
        "total_cost_bdt",
        "peak_grid_kwh",
        "plan_summary",
    }
    missing = required_keys - set(body.keys())
    if missing:
        print(f"RESULT: FAILED (missing keys in response: {missing})")
        return False

    if len(body["hourly_plan"]) != 24:
        print(
            f"RESULT: FAILED (expected 24 hourly_plan entries, got {len(body['hourly_plan'])})"
        )
        return False

    print_header("SUMMARY")
    print(f"Scenario ID       : {body['scenario_id']}")
    print(f"Total grid kWh    : {body['total_grid_kwh']}")
    print(f"Total cost (BDT)  : {body['total_cost_bdt']}")
    print(f"Peak grid kWh     : {body['peak_grid_kwh']}")
    print(f"Plan summary      : {body['plan_summary']}")
    print("\nHourly plan:")
    print(
        f"{'Hr':>3} | {'Grid':>6} | {'Solar':>6} | {'Action':>9} | {'BattKwh':>8} | {'BattAfter':>9}"
    )
    for entry in body["hourly_plan"]:
        print(
            f"{entry['hour']:>3} | {entry['grid_kwh']:>6} | {entry['solar_used_kwh']:>6} | "
            f"{entry['battery_action']:>9} | {entry['battery_kwh']:>8} | "
            f"{entry['battery_energy_after_kwh']:>9}"
        )

    print("\nRESULT: PASSED")
    return True


def main() -> None:
    health_ok = test_health()
    if not health_ok:
        print("\nAborting further tests since /health check failed.")
        sys.exit(1)

    optimize_ok = test_optimize_energy()

    print_header("FINAL RESULT")
    if health_ok and optimize_ok:
        print("ALL TESTS PASSED")
        sys.exit(0)
    else:
        print("SOME TESTS FAILED")
        sys.exit(1)


if __name__ == "__main__":
    main()
