"""
optimizer.py

Formulates and solves the 24-hour GridWise energy dispatch problem as a
Linear Program using PuLP (CBC solver), after applying LLM-derived
operator directives on top of the base scenario data.
"""

from typing import List, Dict, Any, Optional
import pulp

HOURS = list(range(24))
EPSILON = 1e-4


def _apply_directives(
    input_data: Dict[str, Any], directives: List[Dict[str, Any]]
) -> Dict[str, List[float]]:
    """
    Turn the base scenario + directive list into per-hour effective
    parameter arrays used to build the LP model.
    """
    battery = input_data["battery"]
    capacity_kwh = float(battery["capacity_kwh"])
    base_reserve = float(battery["min_reserve_kwh"])
    base_max_charge = float(battery["max_charge_kwh_per_hour"])
    base_max_discharge = float(battery["max_discharge_kwh_per_hour"])
    solar_forecast = [float(x) for x in input_data["solar_forecast_kwh"]]

    effective_solar = list(solar_forecast)
    active_reserve = [base_reserve for _ in HOURS]
    max_charge = [base_max_charge for _ in HOURS]
    max_discharge = [base_max_discharge for _ in HOURS]
    max_grid: List[Optional[float]] = [None for _ in HOURS]

    for directive in directives:
        if not directive.get("applies"):
            continue

        d_type = directive.get("type")
        adj = directive.get("structured_adjustment") or {}
        hours = adj.get("hours", []) or []
        valid_hours = [h for h in hours if isinstance(h, int) and 0 <= h <= 23]

        if d_type == "solar_reduction":
            factor = adj.get("factor", 1.0)
            for h in valid_hours:
                effective_solar[h] = effective_solar[h] * factor

        elif d_type == "minimum_battery_reserve":
            value_kwh = adj.get("value_kwh", base_reserve)
            for h in valid_hours:
                active_reserve[h] = max(active_reserve[h], value_kwh)

        elif d_type == "no_charge_window":
            for h in valid_hours:
                max_charge[h] = 0.0

        elif d_type == "no_discharge_window":
            for h in valid_hours:
                max_discharge[h] = 0.0

        elif d_type == "max_grid_window":
            grid_cap = adj.get("max_grid_kwh", None)
            if grid_cap is not None:
                for h in valid_hours:
                    if max_grid[h] is None:
                        max_grid[h] = grid_cap
                    else:
                        max_grid[h] = min(max_grid[h], grid_cap)

    # Clamp reserve so it never exceeds physical capacity.
    active_reserve = [min(r, capacity_kwh) for r in active_reserve]
    effective_solar = [max(0.0, s) for s in effective_solar]

    return {
        "effective_solar": effective_solar,
        "active_reserve": active_reserve,
        "max_charge": max_charge,
        "max_discharge": max_discharge,
        "max_grid": max_grid,
    }


def solve_energy_optimization(
    input_data: Dict[str, Any], directives: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Solves the 24-hour LP dispatch problem.

    input_data is expected to be a dict with keys:
        scenario_id, demand_kwh (len 24), solar_forecast_kwh (len 24),
        tariff_bdt_per_kwh (len 24),
        battery: {capacity_kwh, initial_energy_kwh, min_reserve_kwh,
                  max_charge_kwh_per_hour, max_discharge_kwh_per_hour}

    directives is the output of llm_parser.parse_operator_notes.
    """
    demand = [float(x) for x in input_data["demand_kwh"]]
    tariff = [float(x) for x in input_data["tariff_bdt_per_kwh"]]
    battery = input_data["battery"]
    capacity_kwh = float(battery["capacity_kwh"])
    initial_energy_kwh = float(battery["initial_energy_kwh"])

    params = _apply_directives(input_data, directives)
    effective_solar = params["effective_solar"]
    active_reserve = params["active_reserve"]
    max_charge = params["max_charge"]
    max_discharge = params["max_discharge"]
    max_grid = params["max_grid"]

    prob = pulp.LpProblem("GridWise_Energy_Dispatch", pulp.LpMinimize)

    grid_kwh = {
        h: pulp.LpVariable(f"grid_kwh_{h}", lowBound=0) for h in HOURS
    }
    solar_used_kwh = {
        h: pulp.LpVariable(f"solar_used_kwh_{h}", lowBound=0, upBound=effective_solar[h])
        for h in HOURS
    }
    charge = {
        h: pulp.LpVariable(f"charge_{h}", lowBound=0, upBound=max_charge[h])
        for h in HOURS
    }
    discharge = {
        h: pulp.LpVariable(f"discharge_{h}", lowBound=0, upBound=max_discharge[h])
        for h in HOURS
    }
    battery_energy_after_kwh = {
        h: pulp.LpVariable(
            f"battery_energy_after_kwh_{h}",
            lowBound=min(active_reserve[h], capacity_kwh),
            upBound=capacity_kwh,
        )
        for h in HOURS
    }

    # 1. Hourly energy balance
    for h in HOURS:
        prob += (
            grid_kwh[h] + solar_used_kwh[h] + discharge[h]
            == demand[h] + charge[h],
            f"energy_balance_{h}",
        )

    # 5. State dynamics
    prob += (
        battery_energy_after_kwh[0]
        == initial_energy_kwh + charge[0] - discharge[0],
        "state_dynamics_0",
    )
    for h in HOURS[1:]:
        prob += (
            battery_energy_after_kwh[h]
            == battery_energy_after_kwh[h - 1] + charge[h] - discharge[h],
            f"state_dynamics_{h}",
        )

    # 6. End-of-day neutrality
    prob += (
        battery_energy_after_kwh[23] == initial_energy_kwh,
        "end_of_day_neutrality",
    )

    # 7. Grid cap (max_grid_window)
    for h in HOURS:
        if max_grid[h] is not None:
            prob += (grid_kwh[h] <= max_grid[h], f"max_grid_window_{h}")

    # Objective: minimize total grid cost
    prob += pulp.lpSum(grid_kwh[h] * tariff[h] for h in HOURS), "total_grid_cost"

    solver = pulp.PULP_CBC_CMD(msg=0)
    prob.solve(solver)

    status = pulp.LpStatus[prob.status]
    if status != "Optimal":
        raise RuntimeError(
            f"Optimization did not converge to an optimal solution. Solver status: {status}"
        )

    hourly_plan = []
    total_grid_kwh = 0.0
    total_cost_bdt = 0.0
    peak_grid_kwh = 0.0

    for h in HOURS:
        g = grid_kwh[h].varValue or 0.0
        s = solar_used_kwh[h].varValue or 0.0
        c = charge[h].varValue or 0.0
        dch = discharge[h].varValue or 0.0
        bat_after = battery_energy_after_kwh[h].varValue or 0.0

        if c > EPSILON:
            action = "charge"
        elif dch > EPSILON:
            action = "discharge"
        else:
            action = "idle"

        net_battery_flow = round(c - dch, 2)
        hour_cost = g * tariff[h]

        hourly_plan.append(
            {
                "hour": h,
                "grid_kwh": round(g, 2),
                "solar_used_kwh": round(s, 2),
                "battery_action": action,
                "battery_kwh": net_battery_flow,
                "battery_energy_after_kwh": round(bat_after, 2),
            }
        )

        total_grid_kwh += g
        total_cost_bdt += hour_cost
        peak_grid_kwh = max(peak_grid_kwh, g)

    applied_directives = [d for d in directives if d.get("applies")]
    if applied_directives:
        summary_parts = [
            f"{d['type']} ({', '.join(str(h) for h in (d['structured_adjustment'] or {}).get('hours', []))})"
            for d in applied_directives
        ]
        directive_summary = "Applied directives: " + "; ".join(summary_parts) + ". "
    else:
        directive_summary = "No operator directives were applied. "

    plan_summary = (
        f"{directive_summary}"
        f"Total grid import over 24h is {round(total_grid_kwh, 2)} kWh at a total cost of "
        f"{round(total_cost_bdt, 2)} BDT, with a peak hourly grid draw of "
        f"{round(peak_grid_kwh, 2)} kWh."
    )

    return {
        "scenario_id": input_data.get("scenario_id"),
        "directive_interpretation": directives,
        "hourly_plan": hourly_plan,
        "total_grid_kwh": round(total_grid_kwh, 2),
        "total_cost_bdt": round(total_cost_bdt, 2),
        "peak_grid_kwh": round(peak_grid_kwh, 2),
        "plan_summary": plan_summary,
    }
