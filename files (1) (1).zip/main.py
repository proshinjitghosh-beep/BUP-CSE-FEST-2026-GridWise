"""
main.py

FastAPI application for the GridWise challenge (BUP CSE Fest 2026,
Preliminary Round). Exposes:

    GET  /health           -> liveness check
    POST /optimize-energy  -> full LLM-directive + LP-optimization pipeline
"""

import logging
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, field_validator

import llm_parser
import optimizer

logger = logging.getLogger("gridwise.main")
logging.basicConfig(level=logging.INFO)

app = FastAPI(
    title="GridWise Optimization Service",
    description=(
        "Backend service that interprets natural-language operator notes "
        "with an LLM and solves a 24-hour battery/grid/solar dispatch "
        "problem with linear programming."
    ),
    version="1.0.0",
)


# ---------------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------------
class BatteryConfig(BaseModel):
    capacity_kwh: float = Field(..., gt=0)
    initial_energy_kwh: float = Field(..., ge=0)
    min_reserve_kwh: float = Field(..., ge=0)
    max_charge_kwh_per_hour: float = Field(..., ge=0)
    max_discharge_kwh_per_hour: float = Field(..., ge=0)

    @field_validator("initial_energy_kwh")
    @classmethod
    def initial_not_exceed_capacity(cls, v, info):
        capacity = info.data.get("capacity_kwh")
        if capacity is not None and v > capacity:
            raise ValueError("initial_energy_kwh cannot exceed capacity_kwh")
        return v

    @field_validator("min_reserve_kwh")
    @classmethod
    def reserve_not_exceed_capacity(cls, v, info):
        capacity = info.data.get("capacity_kwh")
        if capacity is not None and v > capacity:
            raise ValueError("min_reserve_kwh cannot exceed capacity_kwh")
        return v


class GridWiseInput(BaseModel):
    scenario_id: str
    demand_kwh: List[float]
    solar_forecast_kwh: List[float]
    tariff_bdt_per_kwh: List[float]
    battery: BatteryConfig
    operator_notes: Optional[List[str]] = Field(default_factory=list)

    @field_validator("demand_kwh", "solar_forecast_kwh", "tariff_bdt_per_kwh")
    @classmethod
    def must_have_24_hours(cls, v):
        if len(v) != 24:
            raise ValueError("must contain exactly 24 hourly values (hours 0-23)")
        return v


class HealthResponse(BaseModel):
    status: str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(status="ok")


@app.post("/optimize-energy")
def optimize_energy(payload: GridWiseInput):
    try:
        directives = llm_parser.parse_operator_notes(
            notes=payload.operator_notes or [],
            battery_capacity=payload.battery.capacity_kwh,
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception("Directive parsing failed")
        raise HTTPException(
            status_code=500, detail=f"Failed to interpret operator notes: {exc}"
        )

    try:
        input_data = payload.model_dump()
        result = optimizer.solve_energy_optimization(input_data, directives)
    except RuntimeError as exc:
        logger.exception("Optimization solver did not find an optimal solution")
        raise HTTPException(status_code=500, detail=str(exc))
    except Exception as exc:  # noqa: BLE001
        logger.exception("Optimization failed")
        raise HTTPException(
            status_code=500, detail=f"Failed to solve optimization model: {exc}"
        )

    return result


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
