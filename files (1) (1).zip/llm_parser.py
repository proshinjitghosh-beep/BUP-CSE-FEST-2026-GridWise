"""
llm_parser.py

Uses the official Google GenAI SDK (google-genai) to convert free-text
operator notes into strictly structured "directive" objects that the
optimizer (optimizer.py) can consume directly.

Environment variables:
    GEMINI_API_KEY - required to actually call the Gemini API. If it is
    missing, or if the API call fails for any reason, this module falls
    back to safe "no_op" directives for every note so the rest of the
    pipeline keeps working instead of crashing the whole request.
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional

from pydantic import BaseModel

from google import genai
from google.genai import types

logger = logging.getLogger("gridwise.llm_parser")
logging.basicConfig(level=logging.INFO)

GEMINI_MODEL = "gemini-2.5-flash"

ALLOWED_DIRECTIVE_TYPES = [
    "solar_reduction",
    "minimum_battery_reserve",
    "no_charge_window",
    "no_discharge_window",
    "max_grid_window",
    "no_op",
]


# ---------------------------------------------------------------------------
# Structured output schema (used as response_schema for Gemini JSON mode)
# ---------------------------------------------------------------------------
class DirectiveItem(BaseModel):
    note: str
    directive_type: str
    applies: bool
    hours: Optional[List[int]] = None
    factor: Optional[float] = None
    value_kwh: Optional[float] = None
    max_grid_kwh: Optional[float] = None


class DirectiveList(BaseModel):
    directives: List[DirectiveItem]


# ---------------------------------------------------------------------------
# Prompt construction
# ---------------------------------------------------------------------------
def _build_prompt(notes: List[str], battery_capacity: float) -> str:
    notes_json = json.dumps(notes, ensure_ascii=False)

    prompt = f"""You are an energy-grid operations directive interpreter for the
GridWise system. You will be given a JSON array of free-text operator notes
written by a human grid operator. Convert EACH note into exactly one
structured directive object. Return exactly one directive per input note,
in the same order as the input array.

BATTERY CAPACITY (kWh) for this scenario: {battery_capacity}

ALLOWED directive_type values (use exactly one of these strings):
- "solar_reduction": solar generation should be reduced during certain hours.
  structured fields to fill: hours (list[int]), factor (float, e.g. 0.5 means
  50% of forecast solar remains available).
- "minimum_battery_reserve": battery must be kept above some energy level
  during certain hours. structured fields to fill: hours (list[int]),
  value_kwh (float). If the note gives a PERCENTAGE instead of an absolute
  kWh value, you MUST compute value_kwh yourself as:
  battery_capacity * percentage / 100, using the battery capacity given
  above, and return the resulting absolute kWh number (not the percentage).
- "no_charge_window": battery charging must be disabled during certain hours.
  structured fields to fill: hours (list[int]).
- "no_discharge_window": battery discharging must be disabled during certain
  hours. structured fields to fill: hours (list[int]).
- "max_grid_window": grid import must be capped during certain hours.
  structured fields to fill: hours (list[int]), max_grid_kwh (float).
- "no_op": the note does not correspond to any actionable directive, is
  purely informational, or is ambiguous/unsupported. Set applies to false
  and leave hours/factor/value_kwh/max_grid_kwh as null.

HOUR CONVERSION RULES (CRITICAL - read carefully):
- Use 24-hour, 0-indexed hours, where hour h represents the interval
  [h:00, h+1:00).
- Time ranges are START-INCLUSIVE and END-EXCLUSIVE.
- Example: "1 PM to 3 PM" means hours [13, 14] (13:00-14:00 and
  14:00-15:00 are included; 15:00-16:00 is NOT included).
- Example: "6 PM to 9 PM" means hours [18, 19, 20].
- Example: "from 10am to 12pm" means hours [10, 11].
- If a note says a single hour like "at 5 PM", interpret it as just that one
  hour: [17].
- If a note refers to "midnight to 6 AM" that means hours [0, 1, 2, 3, 4, 5].

OUTPUT FORMAT:
Return ONLY a JSON object with a single top-level key "directives", whose
value is a JSON array with exactly {len(notes)} objects (one per input note,
in the same order). Each object must have keys: note, directive_type,
applies, hours, factor, value_kwh, max_grid_kwh. Use null for any field
that does not apply to the chosen directive_type. Do not include any
explanation, markdown formatting, or text outside the JSON object.

INPUT OPERATOR NOTES (JSON array, in order):
{notes_json}
"""
    return prompt


# ---------------------------------------------------------------------------
# Fallback (used when API key is missing or the call fails)
# ---------------------------------------------------------------------------
def _fallback_no_op(notes: List[str], reason: str) -> List[Dict[str, Any]]:
    logger.warning("Falling back to no_op directives for all notes: %s", reason)
    result = []
    for note in notes:
        result.append(
            {
                "note": note,
                "type": "no_op",
                "applies": False,
                "structured_adjustment": None,
            }
        )
    return result


# ---------------------------------------------------------------------------
# Post-processing: convert a validated DirectiveItem into the exact
# structured_adjustment shape required by the optimizer.
# ---------------------------------------------------------------------------
def _to_output_directive(item: "DirectiveItem", battery_capacity: float) -> Dict[str, Any]:
    directive_type = item.directive_type if item.directive_type in ALLOWED_DIRECTIVE_TYPES else "no_op"
    applies = bool(item.applies) and directive_type != "no_op"

    structured_adjustment: Optional[Dict[str, Any]] = None

    if applies:
        hours = item.hours if item.hours else []
        # Defensive clamp: hours must be valid 0-23 ints
        hours = [h for h in hours if isinstance(h, int) and 0 <= h <= 23]

        if directive_type == "solar_reduction":
            factor = item.factor if item.factor is not None else 1.0
            factor = max(0.0, min(1.0, float(factor)))
            structured_adjustment = {"hours": hours, "factor": round(factor, 4)}

        elif directive_type == "minimum_battery_reserve":
            value_kwh = item.value_kwh if item.value_kwh is not None else 0.0
            value_kwh = max(0.0, min(float(battery_capacity), float(value_kwh)))
            structured_adjustment = {"hours": hours, "value_kwh": round(value_kwh, 2)}

        elif directive_type in ("no_charge_window", "no_discharge_window"):
            structured_adjustment = {"hours": hours}

        elif directive_type == "max_grid_window":
            max_grid_kwh = item.max_grid_kwh if item.max_grid_kwh is not None else 0.0
            max_grid_kwh = max(0.0, float(max_grid_kwh))
            structured_adjustment = {"hours": hours, "max_grid_kwh": round(max_grid_kwh, 2)}

        if not hours:
            # A directive with no valid hours cannot apply to anything.
            applies = False
            structured_adjustment = None
            directive_type = "no_op"

    if not applies:
        directive_type = "no_op"
        structured_adjustment = None

    return {
        "note": item.note,
        "type": directive_type,
        "applies": applies,
        "structured_adjustment": structured_adjustment,
    }


# ---------------------------------------------------------------------------
# Public entrypoint
# ---------------------------------------------------------------------------
def parse_operator_notes(
    notes: List[str], battery_capacity: float
) -> List[Dict[str, Any]]:
    """
    Convert a list of free-text operator notes into structured directives.

    Returns a list (same length as `notes`) of dicts:
        {
            "note": str,
            "type": one of ALLOWED_DIRECTIVE_TYPES,
            "applies": bool,
            "structured_adjustment": dict | None
        }
    """
    if not notes:
        return []

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return _fallback_no_op(notes, "GEMINI_API_KEY environment variable is not set")

    try:
        client = genai.Client(api_key=api_key)
        prompt = _build_prompt(notes, battery_capacity)

        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=DirectiveList,
                temperature=0.0,
            ),
        )

        parsed: Optional[DirectiveList] = getattr(response, "parsed", None)

        if parsed is None:
            raw_text = response.text
            if raw_text is None:
                raise ValueError("Empty response from Gemini API")
            cleaned = raw_text.strip()
            if cleaned.startswith("```"):
                cleaned = cleaned.strip("`")
                if cleaned.lower().startswith("json"):
                    cleaned = cleaned[4:]
            data = json.loads(cleaned)
            parsed = DirectiveList.model_validate(data)

        items = parsed.directives

        if len(items) != len(notes):
            logger.warning(
                "Gemini returned %d directives for %d notes; reconciling by index.",
                len(items),
                len(notes),
            )
            reconciled: List[DirectiveItem] = []
            for i, note in enumerate(notes):
                if i < len(items):
                    reconciled.append(items[i])
                else:
                    reconciled.append(
                        DirectiveItem(note=note, directive_type="no_op", applies=False)
                    )
            items = reconciled

        output = [
            _to_output_directive(item, battery_capacity) for item in items
        ]
        return output

    except Exception as exc:  # noqa: BLE001 - broad by design, must never crash the API
        logger.exception("Gemini directive parsing failed")
        return _fallback_no_op(notes, f"{type(exc).__name__}: {exc}")
